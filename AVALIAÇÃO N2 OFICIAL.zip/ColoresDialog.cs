﻿using System;
using System.Drawing;
using System.Windows.Forms;

namespace AVALIAÇÃO_N2_OFICIAL
{
    internal class ColoresDialog
    {
        public Color Colores { get; internal set; }

        internal DialogResult ShowDialog() => throw new NotImplementedException();
    }
}